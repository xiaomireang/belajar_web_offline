# absen-siswa-ci
Absensi siswa online menggunakan framework ci
<h2>Fitur</h2>
<ul>
<li>Login - logout</li>
<li>Hak akses</li>
<li>Guru dapat mengkonfirmasi siswa yang tidak masuk</li>
<li>Struktur kelas</li>
<li>Dibuat dengan CI</li>
</ul>
<small>Masoh banyak yang kurang, Anda juga bisa mengembangkanyya</small>
# Spesifikasi
<ul>
  <li>PHP 7.1.1</li>
  <li>Codeigniter 3.1.5</li>
  <li>Bootstrap 3.3.7</li>
  <li>query 3.2.1</li>
  <li>Database driver : mysqli</li>
</ul>

