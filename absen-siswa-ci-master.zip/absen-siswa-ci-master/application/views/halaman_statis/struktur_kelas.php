<main class="col-sm-9 ml-sm-auto col-md-10 pt-3" role="main">
<section class="row text-center placeholders">
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAAJ12AAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Wali kelas</h4>
              <div class="text-muted">// Nama wali kelasnya</div>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="https://scontent.fcgk1-1.fna.fbcdn.net/v/t1.0-9/13716143_270891449934093_9060547889743007728_n.jpg?oh=a535494e3473efef652f5e7acbe734b0&oe=5A5D247D" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Ketua kelas</h4>
              <span class="text-muted">Kevin hendra wijaya</span>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="https://scontent.fcgk1-1.fna.fbcdn.net/v/t1.0-9/13342891_1772785886341097_6875838827034711404_n.jpg?oh=65b5923b21ec252ecb8710a616607797&oe=5A59CC2F" width="200" height="200" class="img-fluid rounded-circle" alt="Sekretaris kelas exmp;;;">
              <h4>Sekretaris</h4>
              <span class="text-muted">Aldin abbl</span>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="https://scontent.fcgk1-1.fna.fbcdn.net/v/t1.0-0/p206x206/15193698_163646374103650_3813390163821957747_n.jpg?oh=d3e0d766a1df037b44bc913b3130ed66&oe=5A1A5E8E" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Bendahara</h4>
              <span class="text-muted">Wawan kurniawan</span>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAAJ12AAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Wali kelas</h4>
              <div class="text-muted">// Nama wali kelasnya</div>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAADcgwAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Ketua kelas</h4>
              <span class="text-muted">//Nama ketua kelas</span>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAAJ12AAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Sekretaris</h4>
              <span class="text-muted">//Sekretaris</span>
            </div>
            <div class="col-6 col-sm-3 placeholder">
              <img src="data:image/gif;base64,R0lGODlhAQABAIABAADcgwAAACwAAAAAAQABAAACAkQBADs=" width="200" height="200" class="img-fluid rounded-circle" alt="Generic placeholder thumbnail">
              <h4>Anak badung</h4>
              <span class="text-muted">Badung anak</span>
            </div>
          </section>
        </main>
