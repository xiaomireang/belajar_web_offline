<main class="col-sm-9 ml-sm-auto col-md-10 pt-3" role="main">
  
<a class="btn btn-success" href="<?php echo base_url('dashboard/list_siswa/12/rpl'); ?>" role="button">XI RPl</a>
</main>
