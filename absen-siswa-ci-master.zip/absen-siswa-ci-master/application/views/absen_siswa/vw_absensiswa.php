<main class="col-sm-9 ml-sm-auto col-md-10 pt-3" role="main">
  <a class="btn btn-success" href="<?php echo base_url('dashboard/absen_list/12/rpl'); ?>" role="button">XI RPL</a>
  <a class="btn btn-success" href="<?php echo base_url('dashboard/absen_list/12/aph'); ?>" role="button">XI APH</a>
  <a class="btn btn-success" href="<?php echo base_url('dashboard/absen_list/12/tkr'); ?>" role="button">XI TKR</a>
  <a class="btn btn-success" href="<?php echo base_url('dashboard/absen_list/12/tsm'); ?>" role="button">XI TSM</a>
  <a class="btn btn-success" href="<?php echo base_url('dashboard/absen_list/12/mm1'); ?>" role="button">XI MM1</a>
</main>
