<?php 
// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
if(isset($_POST['approve'])){
			$judul = $_POST['judul'];
			$tanggal = $_POST['tanggal'];
			$pegawai = $_POST['pegawai'];
			$status = $_POST['status'];
			$file	= $_POST['file_name'];
			$id     = $_POST['id_file'];

// update data ke database
$query = mysqli_query($koneksi,"UPDATE upload SET judul='$judul', nama_file='$file', pegawai='$pegawai', tanggal='$tanggal', status='$status' WHERE id_file=$id");
			if($query){
						echo 'BERHASIL DI APPROVE';
					}else{
						echo 'GAGAL APPROVE';
					}
				}
// mengalihkan halaman kembali ke index.php
header("location:halaman_admin.php");

?>

<?php
  include 'koneksi.php';
  $query  = mysqli_query($koneksi, "SELECT * FROM upload ORDER BY id_file DESC");
  ?>

  <div class="content table-responsive table-full-width">
   <table class="table table-striped">
      <thead>
         <th class="text-center">Judul</th>
         <th class="text-center">Nama File</th>
         <th class="text-center">Nama Pegawai</th>
         <th class="text-center">Tanggal Upload</th>
         <th class="text-center">Status</th>
      </thead>
      <tbody style="height: 100vh;">
         <?php if(mysqli_num_rows($query)) {?>
         <?php while($row = mysqli_fetch_array($query)) {?>
            <tr>
               <td class="text-center"><?php echo $row['judul'] ?></td>
               <td class="text-center"><?php echo $row['nama_file'] ?></td>
               <td class="text-center"><?php echo $row['pegawai'] ?></td>
               <td class="text-center"><?php echo $row['tgl'] ?></td>
               <td class="text-center"><?php echo $row['status'] ?></td>
            </tr>
        <?php } ?>
        <?php } ?>
      </tbody>
   </table>
</div>