<?php
require_once("koneksi.php");
    $x=$_POST['x'];
    $file         =$_FILES['file']['tmp_name'];
    $file_name    =$_FILES['file']['name'];
    $acak        = rand(1,99);
    $tujuan_file = $acak.$file_name;
    $tempat_file = 'file/'.$tujuan_foto;
    $judul = $_POST['judul'];
    $status = $_POST['status'];
           
    if (isset($_POST['update'])){
    if (!$file==""){
        $buat_file=$tujuan_file;
        $d = 'file/'.$x;
        @unlink ("$d");
        copy ($file,$tempat_file);
    }else{
        $buat_file=$x;
    }
                $query=mysql_query("UPDATE upload SET nama='$buat_file', judul='$judul', status='$status' WHERE id='$id'")or die (mysql_error());
               
        ?><script language="javascript">alert("Data Berhasil Diupdate")</script><?
        ?><script>document.location='view_image.php';</script><?
        }
    ?>

<!DOCTYPE html>
<html>
<head>
	<title>Halaman Manajer</title>
	<?php
	include 'header.php'
	?>
</head>
<body>
	<?php 
	session_start();

	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=gagal");
	}

	?>
	<br><br>
	<h1>Halaman Manajer</h1>

	<p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
	<a href="logout.php">LOGOUT</a>

	<br/>
	<br/>


	<?php
  include 'koneksi.php';
  $query  = mysqli_query($koneksi, "SELECT * FROM upload where tujuan='manajer' ORDER BY id_file DESC");
  ?>

  <div class="content table-responsive table-full-width">
   <table class="table table-striped">
      <thead>
         <th class="text-center">Judul</th>
         <th class="text-center">Nama File</th>
         <th class="text-center">Nama Pegawai</th>
         <th class="text-center">Tanggal Upload</th>
         <th class="text-center">Status</th>
      </thead>
      <tbody style="height: 100vh;">
         <?php if(mysqli_num_rows($query)) {?>
         <?php while($row = mysqli_fetch_array($query)) {?>
            <tr>
               <td class="text-center"><?php echo $row['judul'] ?></td>
               <td class="text-center"><?php echo $row['nama_file'] ?></td>
               <td class="text-center"><?php echo $row['pegawai'] ?></td>
               <td class="text-center"><?php echo $row['tgl'] ?></td>
               <td class="text-center"><?php echo $row['status'] ?></td>
               <td class="text-center">
               		<a href="file/<?=$row['nama_file'];?>">Download</a>
					<select name="approve"/>
                <!-- Daftar pilihan pada combobox -->
                <option value="TIDAK APPROVE">TIDAK APPROVE</option>
                <option value="APPROVE">APPROVE</option>
            </select>
            <input type="hidden" name="id" value="<?php echo $row['id_file']; ?>">
					<input type="submit" name="submit" value="Submit">
               </td>
            </tr>
        <?php } ?>
        <?php } 
        mysqli_close($koneksi); 
        ?>
      </tbody>
   </table>
</div>

<br>
<br><br><br><br><br><br>
	<?php
		include 'footer.php'
		?>


</body>
</body>
</html>



