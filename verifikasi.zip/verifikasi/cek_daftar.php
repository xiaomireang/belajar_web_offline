<?php 
		include 'koneksi.php';
			$nama		=$_POST['nama'];
			$username	=$_POST['username'];
			$password	=$_POST['password'];
			$email		=$_POST['email'];
			$level		=$_POST['level'];	
			$query = mysqli_query($koneksi, "INSERT INTO user VALUES(NULL,'$nama','$username','$password','$email','$level')");
					if($query){
						echo "<script>alert('Berhasil Mendaftar')</script>";
						header("location:login.php");
					}else{
						echo "<script>alert('Gagal Mendaftar')</script>";
						header("location:daftar.php");
				}
?>