<?php
require_once("koneksi.php");
 
if(isset($_POST['submit'])){
    	$judul 		= $_POST['judul'];
			$tanggal 	= $_POST['tanggal'];
			$pegawai 	= $_POST['pegawai'];
			$status 	= $_POST['status'];
			$file		= $_POST['file_name'];
			$id     	= $_POST['id_file'];
 
    // query update data
    $query = "UPDATE upload SET judul='$judul', nama_file='$file', status='$status' WHERE id_file=$id";
    if(mysqli_query($koneksi, $query)){
        header("Location: halaman_admin.php");
    }else{
        echo "Edit Data Gagal";
    }
}

?>
 

<!DOCTYPE html>
<html>
<head>
	<title>Halaman admin</title>
	<?php
	include 'header.php'
	?>
</head>
<body>
	<?php 
	session_start();

	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=gagal");
	}

	?>
	<br><br>
	<h1>Halaman Admin</h1>

	<p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
	<a href="logout.php">LOGOUT</a>

	<br/>
	<br/>


	<?php
  include 'koneksi.php';
  $query  = mysqli_query($koneksi, "SELECT * FROM upload where tujuan='gm' ORDER BY id_file DESC");
  ?>

  <div class="content table-responsive table-full-width">
   <table class="table table-striped">
      <thead>
         <th class="text-center">Judul</th>
         <th class="text-center">Nama File</th>
         <th class="text-center">Nama Pegawai</th>
         <th class="text-center">Tanggal Upload</th>
         <th class="text-center">Status</th>
      </thead>
      <tbody style="height: 100vh;">
         <?php if(mysqli_num_rows($query)) {?>
         <?php while($row = mysqli_fetch_array($query)) {?>
            <tr>
               <td class="text-center"><?php echo $row['judul'] ?></td>
               <td class="text-center"><?php echo $row['nama_file'] ?></td>
               <td class="text-center"><?php echo $row['pegawai'] ?></td>
               <td class="text-center"><?php echo $row['tgl'] ?></td>
               <td class="text-center"><?php echo $row['status'] ?></td>
               <td class="text-center">
               		<a href="file/<?=$row['nama_file'];?>">Download</a>
					<select name="approve"/>
                <!-- Daftar pilihan pada combobox -->
                <option value="TIDAK APPROVE">TIDAK APPROVE</option>
                <option value="APPROVE">APPROVE</option>
            </select>
            <input type="hidden" name="id" value="<?php echo $row['id_file']; ?>">
					<input type="submit" name="submit" value="Submit">
               </td>
            </tr>
        <?php } ?>
        <?php } 
        mysqli_close($koneksi); 
        ?>
      </tbody>
   </table>
</div>

<br>
<br><br><br><br><br><br>
	<?php
		include 'footer.php'
		?>


</body>
</body>
</html>



