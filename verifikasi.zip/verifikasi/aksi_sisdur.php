<!DOCTYPE html>
<html>
	<head>
		<title>Upload File</title>
		<?php
		include 'header.php'
		?>
	</head>
	<body>
		<br>
		<br>
	<h1>Upload Dokumen<br/></h1>

		<?php 
		include 'koneksi.php';
		if($_POST['upload']){
			$ekstensi_diperbolehkan	= array('doc','docx');
			$nama = $_FILES['file']['name'];
			$x = explode('.', $nama);
			$ekstensi = strtolower(end($x));
			$ukuran	= $_FILES['file']['size'];
			$file_tmp = $_FILES['file']['tmp_name'];
			$judul = $_POST['judul'];
			$tanggal = $_POST['tanggal'];
			$pegawai = $_POST['pegawai'];
			$status = $_POST['status'];
			$tujuan = $_POST['tujuan'];

			if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
				if($ukuran < 1044070){			
					move_uploaded_file($file_tmp, 'file/'.$nama);
					$query = mysqli_query($koneksi, "INSERT INTO upload VALUES(NULL,'$judul','$nama','$pegawai','$tanggal','$status','$tujuan')");
					if($query){
						echo 'FILE BERHASIL DI UPLOAD';
					}else{
						echo 'GAGAL MENGUPLOAD FILE';
					}
				}else{
					echo 'UKURAN FILE TERLALU BESAR';
				}
			}else{
				echo 'EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
			}
		}
		?>

		<br/>
		<br/>
		<a href="admin_sisdur.php">Upload Lagi</a>
		<br/>
		<br/>

		
<?php
  include 'koneksi.php';
  $query  = mysqli_query($koneksi, "SELECT * FROM upload ORDER BY id_file DESC");
  ?>

  <div class="content table-responsive table-full-width">
   <table class="table table-striped">
      <thead>
         <th class="text-center">Nama File</th>
         <th class="text-center">Deskripsi</th>
         <th class="text-center">Nama Pegawai</th>
         <th class="text-center">Tanggal Upload</th>
         <th class="text-center">Status</th>
         <th class="text-center">Tujuan</th>
      </thead>
      <tbody style="height: 100vh;">
         <?php if(mysqli_num_rows($query)) {?>
         <?php while($row = mysqli_fetch_array($query)) {?>
            <tr>
               <td class="text-center"><?php echo $row['nama_file'] ?></td>
               <td class="text-center"><?php echo $row['judul'] ?></td>
               <td class="text-center"><?php echo $row['pegawai'] ?></td>
               <td class="text-center"><?php echo $row['tgl'] ?></td>
               <td class="text-center"><?php echo $row['status'] ?></td>
               <td class="text-center"><?php echo $row['tujuan'] ?></td>
            </tr>
        <?php } ?>
        <?php } ?>
      </tbody>
   </table>
</div>

	
	</body>
</html>