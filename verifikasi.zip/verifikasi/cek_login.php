<?php 
// mengaktifkan session pada php
session_start();

// menghubungkan php dengan koneksi database
include 'koneksi.php';

// menangkap data yang dikirim dari form login
$username = $_POST['username'];
$password = $_POST['password'];


// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"select * from user where username='$username' OR email='$username' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password di temukan pada database
if($cek > 0){

	$data = mysqli_fetch_assoc($login);

	// cek jika user login sebagai admin
	if($data['level']=="manajer"){

		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "manajer";
		// alihkan ke halaman dashboard admin
		header("location:admin_manajer.php");

	// cek jika user login sebagai pegawai
	}else if($data['level']=="sisdur"){
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "sisdur";
		// alihkan ke halaman dashboard pegawai
		header("location:admin_sisdur.php");

	// cek jika user login sebagai pengurus
	}else if($data['level']=="gm"){
		// buat session login dan username
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "gm";
		// alihkan ke halaman dashboard pengurus
		header("location:admin_gm.php");

	}else{

		// alihkan ke halaman login kembali
		header("location:index.php?pesan=gagal");
	}	
}else{
	header("location:index.php?pesan=gagal");
}

?>