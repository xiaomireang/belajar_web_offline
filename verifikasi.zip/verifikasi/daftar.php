<!DOCTYPE html>
<html>
<head>
	<title>DAFTAR</title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-lg-10 col-xl-9 mx-auto">
        <div class="card card-signin flex-row my-5">
          <div class="card-img-left d-none d-md-flex">
             <!-- Background image for card set in CSS! -->
          </div>
          <div class="card-body">
            <h5 class="card-title text-center">DAFTAR</h5>
            <form action="cek_daftar.php" method="post" class="form-signup">
              <div class="form-label-group">
                <input type="text" name="nama" id="inputNama" class="form-control" placeholder="Nama" required autofocus>
                <label for="inputNama">Nama</label>
              </div>
              <div class="form-label-group">
                <input type="text" name="username" id="inputUserame" class="form-control" placeholder="Username/Email" required autofocus>
                <label for="inputUserame">Username</label>
              </div>
              <div class="form-label-group">
                <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
                <label for="inputPassword">Password</label>
              </div>
              <div class="form-label-group">
                <input type="text" name="email" id="inputEmail" class="form-control" placeholder="Email" required autofocus>
                <label for="inputUserame">Email</label>
              </div>
              <div class="form-label-group">
                <div class="dropdown">
            <select name="level" class="dropdown-item" />
                <option value="manajer" class="dropdown-item">MANAJER</option>
                <option value="gm" class="dropdown-item">GM</option>
                <option value="sisdur" class="dropdown-item">SISDUR</option>
            </select>
            </div>
              </div>
              
              <button name="daftar" class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Daftar</button>
            
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<script type="text/javascript" src="query-3.3.1.slim.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>