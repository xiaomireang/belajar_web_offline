<!DOCTYPE html>
<html>
<head>
	<title>Halaman Pegawai</title>
	<?php
		include 'header.php'
		?>
</head>
<body>
	<?php 
	session_start();

	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=gagal");
	}

	?><br><br>
	<h1>Halaman Pegawai</h1>

	<p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
	<a href="logout.php">LOGOUT</a>
	<br />
	<center><form action="aksi_sisdur.php" method="post" enctype="multipart/form-data">		 
		<label for="namafile">Pilih File</label><br>
		<input type="file" name="file" required=""><br>
		<label for="textArea">Deskripsi</label><br> 
		<textarea name="judul" id="judul" rows="4"  cols="50" required=""></textarea><br>
		<label for="pegawai">Pengirim</label><br>
		<input type="text" name="pegawai" value="<?php echo $_SESSION['username']?>" readonly/><br>
		<label for="tanggal">Tanggal Pengiriman</label><br>	
		<input name="tanggal" placeholder="Tanggal Hari Ini"  value="<?php echo date('Y-m-d H:i:s')?>"/><br>		
Pilih Tujuan : 
<select name="tujuan" id="tujuan">
<option selected>--Tujuan--</option>
<option>manajer</option>
<option>gm</option>
</select>           
		<input type="hidden" name="status" value="Belum Approve"/> <br><br>
		<input type="submit" name="upload" value="Kirim">
	</form></center>
	
	

	<br/>
	<br/>

	<?php
		include 'footer.php'
		?>
</body>
</html>