<!DOCTYPE html>
<html>
<head>
	<title>Halaman admin</title>
	<?php
	include 'header.php'
	?>
</head>
<body>
	
	<br/>
	<br/>


	<?php
  include 'koneksi.php';
  $query  = mysqli_query($koneksi, "SELECT * FROM upload ORDER BY id_file DESC");
  ?>
  <div class="content table-responsive table-full-width">
   <table class="table table-striped">
      <thead>
         <th class="text-center">Judul</th>
         <th class="text-center">Nama File</th>
         <th class="text-center">Nama Pegawai</th>
         <th class="text-center">Tanggal Upload</th>
         <th class="text-center">Status</th>
      </thead>
      <tbody style="height: 100vh;">
         <?php if(mysqli_num_rows($query)) {?>
         <?php while($row = mysqli_fetch_array($query)) {?>
            <tr>
               <td class="text-center"><?php echo $row['judul'] ?></td>
               <td class="text-center"><?php echo $row['nama_file'] ?></td>
               <td class="text-center"><?php echo $row['pegawai'] ?></td>
               <td class="text-center"><?php echo $row['tgl'] ?></td>
               <td class="text-center"><?php echo $row['status'] ?></td>
               
            </tr>
        <?php } ?>
        <?php } ?>
      </tbody>
   </table>
</div>
</form>

<br>
<br><br><br><br><br><br>
	<?php
		include 'footer.php'
		?>
</body>
</body>
</html>
